/* ecfrac1.c - energy fractions calculation

  input:  

  output: 
*/


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

using namespace std;
#include <strstream>


#define MAX(a,b)    (a > b ? a : b)
#define MIN(a,b)    (a < b ? a : b)
#define ABS(x)      ((x) < 0 ? -(x) : (x))


#ifdef USE_PCAL

#include "../pc.s/pclib.h"
#define ecfrac pcfrac
#define ecfrac1 pcfrac1
#define ecfrac2 pcfrac2
#define ecfrac3 pcfrac3
#define ecfracratio pcfracratio

#else

#include "eclib.h"

#endif


//#define DEBUG

#include <ap_fixed.h>
//#define NUMBER_OF_BITS_DECIMAL	 24
//#define NUMBER_OF_BITS_FRACTIONAL 8
//typedef ap_ufixed<(NUMBER_OF_BITS_DECIMAL+NUMBER_OF_BITS_FRACTIONAL),NUMBER_OF_BITS_DECIMAL> fp1803_t;



#define FACTOR1 256/*128*/
#define SHIFT1  8


/*xc7vx550tffg1158-1*/


/* 3.24/10/2/0%/3%/~0%/2% (NPEAK=3) */
/* 3.24/10/2/0%/8%/~0%/6% */



void
ecfrac1(fp0201S_t peakcount[3][NPEAK], ap_uint<16> energy[NPEAK][NPEAK][NPEAK][3], hitsume_t hitouttmp1[NPEAK][NPEAK][NPEAK])
{
#pragma HLS ARRAY_PARTITION variable=peakcount complete dim=1
#pragma HLS ARRAY_PARTITION variable=peakcount complete dim=2
#pragma HLS ARRAY_PARTITION variable=energy complete dim=1
#pragma HLS ARRAY_PARTITION variable=energy complete dim=2
#pragma HLS ARRAY_PARTITION variable=energy complete dim=3
#pragma HLS ARRAY_PARTITION variable=energy complete dim=4
#pragma HLS ARRAY_PARTITION variable=hitouttmp1 complete dim=1
#pragma HLS ARRAY_PARTITION variable=hitouttmp1 complete dim=2
#pragma HLS ARRAY_PARTITION variable=hitouttmp1 complete dim=3
#pragma HLS PIPELINE

  uint8_t i,u,v,w;
  uint16_t enU, enV, enW;
  uint8_t Nvalid;
  fp1803_t ensumE;

#ifdef DEBUG
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac1!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac1!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
  ihit = 0;
#endif


  for(u=0; u<NPEAK; u++)
  for(v=0; v<NPEAK; v++)
  for(w=0; w<NPEAK; w++)
  {
    if(energy[u][v][w][0]==0)
    {
#ifdef DEBUG
      cout<<"!!! hitin[peakU="<<+u<<"][peakV="<<+v<<"][peakW="<<+w<<"] empty" << endl;
#endif
      hitouttmp1[u][v][w].sumE = 0;
      for(i=0; i<3; i++) hitouttmp1[u][v][w].peak_sumE[i] = 0.0;
    }
    else
	{



      /* for current hit, get energies for unique peaks only */
      if(peakcount[0][u]==1/*.0*/) enU = energy[u][v][w][0];
      else                     enU = 0;
	  if(peakcount[1][v]==1/*.0*/) enV = energy[u][v][w][1];
      else                     enV = 0;
	  if(peakcount[2][w]==1/*.0*/) enW = energy[u][v][w][2];
      else                     enW = 0;





      /* normalize and get 'UNIQUE energy sum' ensumE */
      Nvalid=0;
      if(enU>0) Nvalid++;
      if(enV>0) Nvalid++;
      if(enW>0) Nvalid++;
      ensumE = enU + enV + enW;
      if(Nvalid == 2) ensumE /= (fp1803_t)2.0;
      else if(Nvalid == 3) ensumE /= (fp1803_t)3.0;


	  /* if it was any UNIQUEs, fill output array(s) */
      /*if(ensumE>0.0)*/
      {

        /* attach 'UNIQUE energy sum' ensumE to the hit to be used in stage 3 of this function (DELIMOE) */
        hitouttmp1[u][v][w].sumE = ensumE;


        /* insert 'UNIQUE energy sum' ensumE into hitouttmp1[][][] only for NOT UNIQUE peaks participating in this hit */
        /* so we are summing/normalizing energies from unique peaks, and placing it into NOT-unique peak for following processing */
        if(enU==0) hitouttmp1[u][v][w].peak_sumE[0] = ensumE;
        else       hitouttmp1[u][v][w].peak_sumE[0] = 0.0;

        if(enV==0) hitouttmp1[u][v][w].peak_sumE[1] = ensumE;
        else       hitouttmp1[u][v][w].peak_sumE[1] = 0.0;

        if(enW==0) hitouttmp1[u][v][w].peak_sumE[2] = ensumE;
        else       hitouttmp1[u][v][w].peak_sumE[2] = 0.0;




#ifdef DEBUG
        cout<<"   !!! enU="<<enU<<" enV="<<enV<<" enW="<<enW<<" -> Nvalid="<<+Nvalid<<" -> hitouttmp1["<<+u<<"]["<<+v<<"]["<<+w<<"].sumE="<<hitouttmp1[u][v][w].sumE<<endl;
        cout<<endl;
#endif

      }



#ifdef DEBUG
      ihit ++;
#endif
	}
  }
#ifdef DEBUG
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac1!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac1!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
#endif

  return;
}

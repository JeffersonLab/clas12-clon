/* ecfrac.c - energy fractions calculation

  input:  

  output: 
*/


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

using namespace std;
#include <strstream>


#define MAX(a,b)    (a > b ? a : b)
#define MIN(a,b)    (a < b ? a : b)
#define ABS(x)      ((x) < 0 ? -(x) : (x))


#ifdef USE_PCAL

#include "../pc.s/pclib.h"
#define ecfrac pcfrac
#define ecfrac1 pcfrac1
#define ecfrac2 pcfrac2
#define ecfrac3 pcfrac3
#define ecfracratio pcfracratio

#else

#include "eclib.h"

#endif


//#define DEBUG

#include <ap_fixed.h>
//#define NUMBER_OF_BITS_DECIMAL	 24
//#define NUMBER_OF_BITS_FRACTIONAL 8
//typedef ap_ufixed<(NUMBER_OF_BITS_DECIMAL+NUMBER_OF_BITS_FRACTIONAL),NUMBER_OF_BITS_DECIMAL> fp1803_t;



#define FACTOR1 256/*128*/
#define SHIFT1  8


/*xc7vx550tffg1158-1*/


/* 3.36/64/12/0%/0%/2%/6% */

void ecfrac1(fp0201S_t peakcount[3][NPEAK], ap_uint<16> energy[NPEAK][NPEAK][NPEAK][3], hitsume_t hitouttmp1[NPEAK][NPEAK][NPEAK]);
void ecfrac2(hitsume_t hitouttmp1[NPEAK][NPEAK][NPEAK], hitsume_t hitouttmp2[NPEAK][NPEAK][NPEAK]);
void ecfrac3(hitsume_t hitouttmp2[NPEAK][NPEAK][NPEAK], uint32_t fracout[NPEAK][NPEAK][NPEAK][3]);


void
ecfrac(fp0201S_t peakcount[3][NPEAK], hitout_t hitin[NPEAK][NPEAK][NPEAK], uint32_t fracout[NPEAK][NPEAK][NPEAK][3])
{
#pragma HLS ARRAY_PARTITION variable=peakcount complete dim=1
#pragma HLS ARRAY_PARTITION variable=peakcount complete dim=2
#pragma HLS ARRAY_PARTITION variable=hitin complete dim=1
#pragma HLS ARRAY_PARTITION variable=hitin complete dim=2
#pragma HLS ARRAY_PARTITION variable=hitin complete dim=3
#pragma HLS ARRAY_PARTITION variable=fracout complete dim=1
#pragma HLS ARRAY_PARTITION variable=fracout complete dim=2
#pragma HLS ARRAY_PARTITION variable=fracout complete dim=3
#pragma HLS PIPELINE

  uint8_t i, j, u, v, w, ihit, axis;
  uint32_t fractmp;
  uint8_t Nvalid;
  hitout_t hitouttmp;
  uint16_t enU, enV, enW;
  fp1803_t ensumE;
  fp1803_t peak_sumE[3][NPEAK];

  hitsume_t hitouttmp1[NPEAK][NPEAK][NPEAK];
  hitsume_t hitouttmp2[NPEAK][NPEAK][NPEAK];

  ap_uint<16> energy[NPEAK][NPEAK][NPEAK][3];

#ifdef DEBUG
  printf("\n\n\n+++ ecfrac +++\n\n\n");
#endif


  /* loop for all hits */

#ifdef DEBUG
  printf("entering loop over hits\n\n");
#endif

  for(u=0;u<NPEAK;u++) for(v=0;v<NPEAK;v++) for(w=0;w<NPEAK;w++) for(i=0;i<3;i++) energy[u][v][w][i] = hitin[u][v][w].energy[i];

  ecfrac1(peakcount, energy, hitouttmp1);
  ecfrac2(hitouttmp1, hitouttmp2);
  ecfrac3(hitouttmp2, fracout);



#ifdef DEBUG
  printf("\n\n\n+++ ecfrac done +++\n\n\n");
#endif



  return;
}



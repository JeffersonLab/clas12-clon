/* ecfrac3.c - energy fractions calculation

  input:  

  output: 
*/


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

using namespace std;
#include <strstream>


#define MAX(a,b)    (a > b ? a : b)
#define MIN(a,b)    (a < b ? a : b)
#define ABS(x)      ((x) < 0 ? -(x) : (x))


#ifdef USE_PCAL

#include "../pc.s/pclib.h"
#define ecfrac pcfrac
#define ecfrac1 pcfrac1
#define ecfrac2 pcfrac2
#define ecfrac3 pcfrac3
#define ecfracratio pcfracratio

#else

#include "eclib.h"

#endif


//#define DEBUG

#include <ap_fixed.h>
//#define NUMBER_OF_BITS_DECIMAL	 24
//#define NUMBER_OF_BITS_FRACTIONAL 8
//typedef ap_ufixed<(NUMBER_OF_BITS_DECIMAL+NUMBER_OF_BITS_FRACTIONAL),NUMBER_OF_BITS_DECIMAL> fp1803_t;



#define FACTOR1 256/*128*/
#define SHIFT1  8


/*xc7vx550tffg1158-1*/


/* 3.03/31/2/0%/0%/46%/73%    (fp1803_t)0.0 or 0 */

/*
Generating core module 'ecfrac3_udiv_24ns_21ns_24_28': 192 instance(s). 1269 FFs and 1269 LUTs each
Generating pipelined core: 'ecfrac3_udiv_24ns_21ns_24_28_div
	*/

void
ecfrac3(hitsume_t hitouttmp2[NPEAK][NPEAK][NPEAK], uint32_t/*ap_uint<9>*/ fracout[NPEAK][NPEAK][NPEAK][3])
{
#pragma HLS ARRAY_PARTITION variable=hitouttmp2 complete dim=1
#pragma HLS ARRAY_PARTITION variable=hitouttmp2 complete dim=2
#pragma HLS ARRAY_PARTITION variable=hitouttmp2 complete dim=3
#pragma HLS ARRAY_PARTITION variable=fracout complete dim=1
#pragma HLS ARRAY_PARTITION variable=fracout complete dim=2
#pragma HLS ARRAY_PARTITION variable=fracout complete dim=3
#pragma HLS ARRAY_PARTITION variable=fracout complete dim=4
#pragma HLS PIPELINE

  uint8_t i,u,v,w;
  hitsume_t hitouttmp;
  uint16_t fractmp, tmptmp;

#ifdef DEBUG
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac3!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac3!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
#endif

  /* 3.03/26/2/0%/0%/33%/53%  (fixed 18.3) */
  /* 2.89/23/2/0%/0%/19%/29%  (uint8_t) */
  /* 2.89/23/2/0%/0%/16%/23%  (uint16_t) */

  for(u=0; u<NPEAK; u++)
  for(v=0; v<NPEAK; v++)
  for(w=0; w<NPEAK; w++)
  {
	if(hitouttmp2[u][v][w].sumE>0)
	{
    hitouttmp = hitouttmp2[u][v][w];
    tmptmp = (/*(ap_uint<16>)*/hitouttmp.sumE) * FACTOR1;
    for(i=0; i<3; i++)
    {
      if(hitouttmp.peak_sumE[i]==0)
 	  {
        fracout[u][v][w][i] = FACTOR1;
 	  }
      else
 	  {
        fracout[u][v][w][i] = tmptmp / (/*(ap_uint<16>)*/hitouttmp.peak_sumE[i]);
 	  }
    }
	}
  }

#ifdef DEBUG
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac3!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac3!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
#endif

  return;
}

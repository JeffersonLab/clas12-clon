
/* ecal.c */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#include "eclib.h"

#define THRESHOLD1 ((uint16_t)1)
#define THRESHOLD2 ((uint16_t)1)
#define THRESHOLD3 ((uint16_t)3)

/* 3.60/420/72/1%/5%/13%/33% - parameters ap_fifo, internal arrays complete */
/* 3.48/351/18/11%/7%/23%/54% - same plus params complete */

uint8_t
ecal(ECStrip strip[3][NSTRIP], uint8_t *nhits, ECHit hit[NHIT])
{
#pragma HLS PIPELINE
#pragma HLS ARRAY_PARTITION variable=hit complete dim=1
#pragma HLS ARRAY_PARTITION variable=strip complete dim=1
#pragma HLS INTERFACE ap_memory port=hit
#pragma HLS INTERFACE ap_memory port=strip
  uint8_t ret, sec, uvw, npsble;
  uint8_t npeak[3];
  ECPeak0 peaktmp1[NSTRIP];
  ECPeak0 peaktmp2[NPEAKMAX];
  ECPeak peak[3][NPEAK];
  ECStrip striptmp[NSTRIP];
  hitout_t hitout[NPEAK][NPEAK][NPEAK];

  uint32_t fffout[NPEAK][NPEAK][NPEAK][3];

  fp0201S_t peakcount[3][NPEAK];

  *nhits = 0;

  for(uvw=0; uvw<3; uvw++)
  {
    ecstrip(uvw, &strip[uvw][0], &striptmp[0]);
    npeak[uvw] = ecpeak(THRESHOLD1, &striptmp[0], &peaktmp1[0]);
    ecpeaksort(&peaktmp1[0], &peaktmp2[0]);
    ecpeakcoord(uvw, &peaktmp2[0], &peak[uvw][0]);
  }

  npsble = echit(/*npeak,*/ peak, peakcount, hitout);
  if(npsble)
  {
    ecfrac(peakcount, hitout, fffout);
    *nhits = eccorr(THRESHOLD3, hitout, fffout, &hit[0]);
  }

  return(*nhits);
}

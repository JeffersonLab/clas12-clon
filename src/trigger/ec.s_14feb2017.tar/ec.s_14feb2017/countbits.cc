
/* countbits.cc */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

using namespace std;
#include <strstream>

#if 0
// To initially generate the table algorithmically:
uint8_t BitsSetTable256[256];
BitsSetTable256[0] = 0;
printf("BBBBIIIIII\n");
for (int i = 0; i < 256; i++)
{
   if((i%16)==0) printf("\n");
   BitsSetTable256[i] = (i & 1) + BitsSetTable256[i / 2];
   printf("%2d,",BitsSetTable256[i]);
}
printf("BBBBIIIIIIUUUUUUUUUUUUUUUUUUUUU\n");
#endif



static uint8_t oneBitsInUChar[] = {
// 0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F (<- n)
//  =====================================================
   0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4, // 0n
   1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, // 1n
   1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, // 2n
   2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, // 3n
   1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, // 4n
   2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, // 5n
   2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, // 6n
   3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, // 7n
   1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5, // 8n
   2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, // 9n
   2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, // An
   3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, // Bn
   2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6, // Cn
   3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, // Dn
   3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7, // En
   4, 5, 5, 6, 5, 6, 6, 7, 5, 6, 6, 7, 6, 7, 7, 8  // Fn
};

// Function for fast calculation of bits set in 16-bit unsigned short.

static uint8_t
oneBitsInUShort (uint16_t x)
{
  return( oneBitsInUChar[x>>8] + oneBitsInUChar[x&0xff] );
}

// Function for fast calculation of bits set in 32-bit unsigned int.

static uint8_t
oneBitsInUInt (uint32_t x)
{
  return( oneBitsInUShort(x>>16) + oneBitsInUShort(x& 0xffff) );
}

static uint8_t
oneBitsInULong (uint64_t x)
{
	uint8_t tmp1;
  return( oneBitsInUInt(x>>32) + oneBitsInUInt(x& 0xffffffff) );
}





uint8_t
countbits(uint64_t data)
{
#pragma HLS PIPELINE
  uint8_t ret;
  ret = oneBitsInULong(data);
  return(ret);
}

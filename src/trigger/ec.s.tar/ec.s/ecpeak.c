
/* ecpeak.c - looking for peaks in particular layer

  input:  strip[].energy - strip energy (MeV)
          strip[].time   - strip time (ns)
          threshold      - 
          gap            - 
          min            - 
          max            - 

  output: npeak  - the number of peaks obtained
          peak   - peaks information
*/

	
/*
The usual trick to select the n largest elements is to maintain a min-priority queue.

    Unconditionally insert into the queue the n first elements
    For each remaining element x, insert x if it is greater than the least element of the queue (O(log n) operation),
    and remove the least element (O(log n)).
    When done, the priority queue contains n elements, which are the n largest elements of the original array.

Total complexity: O(N log n) where N is the total number of elements in the array.

I leave to you as an exercise the implementation details (first step is to learn about priority queues, and implement one).
*/


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#include "eclib.h"

#define MAX(a,b)    (a > b ? a : b)
#define MIN(a,b)    (a < b ? a : b)
#define ABS(x)      ((x) < 0 ? -(x) : (x))


/* 3.48/146/18/0%/1%/10%/18% - with intermediate peak array which is 'complete' */
/* 3.48/136/45/0%/1%/0%/1% - no intermediate array, just pipeline */
/* 3.48/109/ 1/0%/1%/19%/32% - no intermediate array, pipeline and complete i/o arrays, same for 'strip block factor=36 / peak block factor=18' */
/* 3.48/136/37/0%/1%/1%/3% - no intermediate array, pipeline and 'strip block factor=18 / peak block factor=9' */
/* 3.48/134/37/0%/1%/1%/3% - no intermediate array, pipeline and 'strip complete dim=1 / peak block factor=9' */
/* 3.44/147/40/0%/1%/1%/2% - no intermediate array, pipeline and 'strip complete dim=1 / peak block factor=2' */
/* 3.48/135/37/0%/1%/1%/3% - no intermediate array, pipeline and 'strip complete dim=1 / peak block factor=16' */
/* 3.48/135/37/0%/1%/1%/3% - no intermediate array, pipeline and 'strip complete dim=1 / peak block factor=17' */
/* 3.48/109/ 1/0%/1%/19%/32% - no intermediate array, pipeline and 'strip complete dim=1 / peak block factor=18' */


/*
Unable to schedule 'load' operation ('strip_energy_load_2', ../../ec.s/ecpeak.c:218) on array 'strip_energy' due to limited memory ports
*/

#undef DEBUG


#define OPEN_PEAK \
  if(peak_opened == 0) strip1 = i; \
  energysum4coord += nstrip*energy; \
  nstrip++; \
  energysum += energy; \
  peak_opened = 1

#define CLOSE_PEAK \
  peak[npeak].strip1   = strip1; \
  peak[npeak].stripn   = nstrip; \
  peak[npeak].energy   = energysum; \
  peak[npeak].energysum4coord = energysum4coord; \
  energysum4coord=0; \
  peak_opened = 0; \
  npeak++; \
  strip1 = 0; \
  nstrip = 0; \
  energysum = 0


int
ecpeak(uint16_t strip_threshold, ECStrip strip[NSTRIP], ECPeak0 peak[NPEAKMAX])
{
#pragma HLS ARRAY_PARTITION variable=strip complete dim=1
#pragma HLS ARRAY_PARTITION variable=peak block factor=18
#pragma HLS PIPELINE
  uint8_t i, j, strip1, nstrip, npeak, peak_opened;
  uint16_t energy, energysum, epeak;
  uint32_t energysum4coord;


#ifdef DEBUG
  printf("\n+++ ecpeak +++\n");
  printf("ecpeak: strip_threshold=%d\n",strip_threshold);
#endif

  peak_opened = 0;
  npeak  = 0;
  strip1 = 0;
  nstrip = 0;
  energysum = 0;
  energysum4coord=0;

  for(i=0; i<NPEAKMAX; i++) peak[i].energy = 0;

  for(i=0; i<NSTRIP; i++)
  {
    energy = strip[i].energy;
#ifdef DEBUG
	printf("strip[%d]: energy=%d (peak_opened=%d)\n",i,energy,peak_opened);
#endif
    if(energy>strip_threshold)
    {
      OPEN_PEAK;
	}
    else if(peak_opened==1)
    {
	  CLOSE_PEAK;
    }
  }

  /* peak still opened after the loop - close it */
  if(peak_opened==1)
  {
#ifdef DEBUG
    printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
#endif
	CLOSE_PEAK;
  }

#ifdef DEBUG
  printf("npeak=%d\n",npeak);
  for(i=0; i<npeak; i++)
  {
    printf("peak[%2d]: energy=%d, energysum4coord=%d, first strip=%d, number of strips=%d\n",
		   i,peak[i].energy,peak[i].energysum4coord,peak[i].strip1,peak[i].stripn);
  }
#endif

  return(npeak);
}

/* ecfrac.c - energy fractions calculation

  input:  

  output: 
*/


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#define MAX(a,b)    (a > b ? a : b)
#define MIN(a,b)    (a < b ? a : b)
#define ABS(x)      ((x) < 0 ? -(x) : (x))

#include "eclib.h"
#include "ecal_atten.h"



#undef DEBUG


#define FACTOR1 256/*128*/
#define SHIFT1  8

#define FACTOR2 128
#define SHIFT2  7

#define SHIFT12 15/*14*/ /* CHANGE IT IF FACTOR1 or FACTOR2 CHANGED: it is shift to get FACTOR1*FACTOR2 */

#define WIN1_LEN  16384 /* max size available for now !!! */


/*xc7vx550tffg1158-1*/


/* 3.39/60/30/1%/4%/1%/6% */



void
ecfrac(uint8_t npeak[3], ECPeak peak_in[3][NPEAK],
	   ECPeak1 peak1[3][NPEAK], uint8_t npsble,
       ECHit hit[NHIT], uint32_t hitfrac[3][NHIT])
{
#pragma HLS PIPELINE
  static uint16_t coeff1[WIN1_LEN];
  static uint16_t att_u[WIN1_LEN];
  static uint16_t att_v[WIN1_LEN];
  static uint16_t att_w[WIN1_LEN];
  int i, j, k, kk, l, ith, axis, edge, ihit, ipeak, peakID, NhitsINpeak, peakn, npks, nhit;
  int attn, lat, fraction[3];
#pragma HLS ARRAY_PARTITION variable=fraction complete dim=1 
  uint16_t fracenergy;
  uint16_t hitenergy;
  uint32_t energysum;
  uint16_t addr;
  uint8_t n,n1,n2; /* shift needed for addr1 and addr2 to be fitted into 7 bit */
  uint16_t uvw[3], dalitz, uvw2[3];
#pragma HLS ARRAY_PARTITION variable=uvw complete dim=1

  ECPeak peak[3][NPEAK];
#pragma HLS ARRAY_PARTITION variable=peak complete dim=1

  int peak_ID, hitID;
  int Nvalid[NPEAK];

  uint32_t fractmp;
  uint32_t sumE0, sumE[NPEAK];



  for(i=0; i<3; i++) for(j=0; j<NPEAK; j++) peak[i][j] = peak_in[i][j];


#ifdef DEBUG
  printf("\n\n\n+++ eccorr +++\n\n\n");
#endif

  nhit = npsble;

  /* loop for all hits */

#ifdef DEBUG
  printf("entering loop over hits\n");
#endif


  for(ihit=0; ihit<NHIT; ihit++)
  {
    if(ihit>=nhit) continue;

    for(edge=0; edge<3; edge++)
    {
      peak_ID = hit[ihit].peak1[edge];
      hitfrac[edge][ihit] = 0;
      if(peak1[edge][peak_ID].nhits == 1)
	  {
        hitfrac[edge][ihit] = 1*FACTOR1;
	  }
    }
  }  



  /*************************/
  /* loop for 3 axis/edges */
  for(edge=0; edge<3; edge++)
  {

	/*********************************/
    /* loop over all peaks in 'edge' */
    for(peakID=0; peakID<NPEAK; peakID++)
    {
      if(peakID>=npeak[edge]) continue;
      NhitsINpeak = peak1[edge][peakID].nhits; /* the number of hits where this peak participates */

#ifdef DEBUG
	  printf("      !!! edge=%d peakID=%d: NhitsINpeak=%d\n",edge,peakID,NhitsINpeak);
#endif

      if(NhitsINpeak > 1) /* if the number of participating hits in current peak more then 1 */
	  {
        sumE0 = 0;


        /*************************************************/
        /* loop over hits, contributed into current peak */
        for(ihit=0; ihit<NHIT; ihit++)
		{
          if(ihit>=NhitsINpeak) continue;
		  hitID = peak1[edge][peakID].hitid[ihit];       /* hit ID */
#ifdef DEBUG
	      printf("      !!!    edge=%d peakID=%d ihit=%d hitID=%d\n",edge,peakID,ihit,hitID);
#endif
          sumE[ihit] = 0;
          Nvalid[ihit] = 0;

		  /* find peaks on other two edges that are involved in this hit only */
          for(axis = 0; axis<3; axis++)
	  	  {
            if(axis != edge)                 /* considering 2 other views */
  		    {
			  peak_ID = hit[hitID].peak1[axis];   /* peak ID for that hit in that view */

#ifdef DEBUG
	          printf("      !!!       -> axis=%d peak_ID=%d peak1.nhits=%d\n",axis,peak_ID,peak1[axis][peak_ID].nhits);
#endif
              if(peak1[axis][peak_ID].nhits == 1)
			  {
                Nvalid[ihit] ++;
				sumE[ihit] += peak[axis][peak_ID].energy /* * hitfrac[axis][hitID] - always =1 ???*/;
#ifdef DEBUG
	            printf("      !!!          -> peak.energy=%d * hitfrac=%d = sumE=%d\n",peak[axis][peak_ID].energy,hitfrac[axis][hitID],sumE[ihit]);
#endif
              }

            }
          }


          /* calculate energy sum for normalization */
          if(Nvalid[ihit] > 0) /* at least one of peaks should be belong to one cluster */
		  {	
			sumE[ihit] /= Nvalid[ihit];
#ifdef DEBUG
	        printf("      !!!          -> Nvalid=%d, sumE[%d]=%d\n",Nvalid[ihit],ihit,sumE[ihit]);
#endif
		  }
          sumE0 += sumE[ihit];
#ifdef DEBUG
	      printf("      !!!    edge=%d sumE0=%d\n",edge,sumE0);
#endif
		}
        /*************************************************/
        /*************************************************/



        if(sumE0 > 0)
		{
          /* loop over hits again normalizing energy */
          for(ihit=0; ihit<NHIT; ihit++)
		  {
            if(ihit>=NhitsINpeak) continue;
            hitID = peak1[edge][peakID].hitid[ihit];       /* hit ID */
            hitfrac[edge][hitID] = (sumE[ihit] * FACTOR1) / sumE0;
#ifdef DEBUG
	        printf("      !!!       -> sumE[%d]=%d / sumE0=%d = hitfrac[%d][%d]=%d\n",ihit,sumE[ihit],sumE0,edge,hitID,hitfrac[edge][hitID]);
#endif
		  }
		  NhitsINpeak = 1;
		}


	  } /* if the number of participating hits in current peak more then 1 */


	}
    /* loop over all peaks in 'edge' */
	/*********************************/


  }
  /* loop for 3 axis/edges */
  /*************************/



  return;
}



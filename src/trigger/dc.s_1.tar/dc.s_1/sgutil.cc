
/* sgutil.cc */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

using namespace std;
#include <strstream>

#include "sgutil.h"



#define DEBUG

#define TRIGGER_STYLE

/*********************/
/* lookup table part */

#define STRLEN 128

#define LONG_BIT 16

#define NADR   0xFFF
static unsigned int look[NADR];   /* 3 summed layers lookup table */

static unsigned short out[NOFFSETS][NW112]; /* segment finding result */
#ifdef TRIGGER_STYLE
static unsigned char input[6][NWIRESTOT]; /* 'trigger-style' segment finding result */
#endif

static int dshift[MAXSEGM][5];
static int shift[MAXSEGM][5];
static int nsegment6;
static int segment6[MAXSEGM][6];

#ifdef TRIGGER_STYLE
static unsigned char outputt[NOFFSETS][NWIRES]; /* 'trigger-style' segment finding result */
#include "cinclude/dcsegfinder.c"
#endif



/* 3 summed layers lookup table: in following example ...

-xx-
-x--
-x--
----
-x--
-xx-

0100
0010
0100
 */


void
AxialPlusStereoInit()
{
  FILE *fd;
  int i, j;
  unsigned long k;
  unsigned char *p;
  char ch, str_tmp[STRLEN], keyword[STRLEN];

  /* get segments from dictionary */
  fd = fopen("segmdict.txt","r");
  if(fd <= NULL)
  {
    printf("ERROR: cannot open segment dictionary file - exit\n");
    exit(0);
  }

  /* Parsing of segment dictionary file */
  while ((ch = getc(fd)) != EOF)
  {
    if ( ch == '#' || ch == ' ' || ch == '\t' )
    {
      while (getc(fd) != '\n') {}
    }
    else if( ch == '\n' ) {}
    else
    {
      ungetc(ch,fd);
      fgets(str_tmp, STRLEN, fd);
      sscanf (str_tmp, "%s", keyword);

      if(strcmp(keyword,"SEGM_DICT") == 0)
      {
        sscanf (str_tmp, "%*s %d", &nsegment6);
        printf("nsegment6=%d\n",nsegment6);
        for(i=0; i<nsegment6; i++)
		{
          fgets(str_tmp, STRLEN, fd);
          sscanf (str_tmp, "%d %d %d %d %d %d",&segment6[i][0],&segment6[i][1],
				  &segment6[i][2],&segment6[i][3],&segment6[i][4],&segment6[i][5]);
          printf(" [%3d] %2d %2d %2d %2d %2d %2d\n",i,segment6[i][0],segment6[i][1],
				  segment6[i][2],segment6[i][3],segment6[i][4],segment6[i][5]);
		}
	  }
	}
  }


  for(i=0; i<nsegment6; i++)
  {
    for(j=0; j<5; j++)
    {
      shift[i][j] = segment6[i][j+1];
	}
  }

  printf("\n\n Shift table:\n");
  for(i=0; i<nsegment6; i++)
  {
    printf("%3d >>> %2d %2d %2d %2d %2d\n",i,shift[i][0],
                          shift[i][1],shift[i][2],shift[i][3],shift[i][4]);
  }
  printf("\n\n");

  /* create differential shift table */

  for(j=0; j<5; j++) dshift[0][j] = 0;
  printf("\n\nDifferential shift table:\n");
  for(i=1; i<nsegment6; i++)
  {
    for(j=0; j<5; j++)
    {
      dshift[i][j] = shift[i][j] - shift[i-1][j];
    }
    printf("%3d >>> %2d %2d %2d %2d %2d\n",i,dshift[i][0],
                          dshift[i][1],dshift[i][2],dshift[i][3],dshift[i][4]);
  }
  printf("\n\n");



  /* lookup table: 3 layers contains # hits in vertical columns */

  for(k=0; k<NADR; k++)
  {
    p = (unsigned char *)&look[k];
    p[0] = ((k&0x1)   )+((k&0x10)>>3)+((k&0x100)>>6)+((k&0x1000)>>9);
    p[1] = ((k&0x2)>>1)+((k&0x20)>>4)+((k&0x200)>>7)+((k&0x2000)>>10);
    p[2] = ((k&0x4)>>2)+((k&0x40)>>5)+((k&0x400)>>8)+((k&0x4000)>>11);
    p[3] = ((k&0x8)>>3)+((k&0x80)>>6)+((k&0x800)>>9)+((k&0x8000)>>12);
  }

  return;
}


/* lookup table part */
/*********************/




























static void
BinaryPrint16(unsigned short k)
{
  int i, lastbit;
  unsigned short j, jj;

  j = 1;
  lastbit = 8*sizeof(short) - 1;
  for(i = 0; i < lastbit; i++) j *= 2;

  jj = j;
  for(i = lastbit; i >=0; i--)
  {
    if(k & jj) fprintf(stdout, "X");
    else       fprintf(stdout, "-");
    
    jj = jj >> 1;
  }

  return;
}

void
PrintWord112(Word112Ptr hw)
{
  int i;
  unsigned short *w;
  w = (unsigned short *)hw->words;
  printf("112> ");
  for(i=(NW112-1); i>=0; i--) {BinaryPrint16(w[i]); printf(" ");}
  printf("\n");

  return;
}






void
CopyWord112(Word112Ptr hws, Word112Ptr hwd)
{
  int i;
  unsigned short *a = (unsigned short *)hws;
  unsigned short *b = (unsigned short *)hwd;
  for(i=0; i<NW256; i++) b[i] = a[i];
  return;
}

void
ANDWord112(Word112Ptr hwa, Word112Ptr hwb, Word112Ptr hwc)
{
  int i;
  unsigned short *a = (unsigned short *)hwa;
  unsigned short *b = (unsigned short *)hwb;
  unsigned short *c = (unsigned short *)hwc;
  for(i=0; i<NW256; i++) c[i] = a[i] & b[i];
  return;
}

void
ORWord112(Word112Ptr hwa, Word112Ptr hwb, Word112Ptr hwc)
{
  int i;
  unsigned short *a = (unsigned short *)hwa;
  unsigned short *b = (unsigned short *)hwb;
  unsigned short *c = (unsigned short *)hwc;
  for(i=0; i<NW256; i++) c[i] = a[i] | b[i];
  return;
}

void
XORWord112(Word112Ptr hwa, Word112Ptr hwb, Word112Ptr hwc)
{
  int i;
  unsigned short *a = (unsigned short *)hwa;
  unsigned short *b = (unsigned short *)hwb;
  unsigned short *c = (unsigned short *)hwc;
  for(i=0; i<NW256; i++) c[i] = a[i] ^ b[i];
  return;
}

void
RightShiftWord112(Word112Ptr hw, int n)
{
  int ii, shift;
  unsigned short *w = (unsigned short *)hw->words;
  shift = LONG_BIT - n;

  hw->lword >>= n;
  hw->lword |= w[0] << shift;

  for(ii=0; ii<(NW112-1); ii++)
  {
    w[ii] >>= n;
    w[ii] |= w[ii+1] << shift;
  }
  w[(NW112-1)] >>= n;

  w[(NW112-1)] |= hw->hword << shift;
  hw->hword >>= n;

  return;
}

void
LeftShiftWord112(Word112Ptr hw, int n)
{
  int ii, shift;
  unsigned short *w = (unsigned short *)hw->words;
  shift = LONG_BIT - n;

  hw->hword <<= n;
  hw->hword |= w[(NW112-1)] >> shift;

  for(ii=(NW112-1); ii>0; ii--)
  {
    w[ii] <<= n;
    w[ii] |= w[ii-1] >> shift;
  }
  w[0] <<= n;

  w[0] |= hw->lword >> shift;
  hw->lword <<= n;

  return;
}

int
CheckBitWord112(Word112Ptr hw, int n)
{
  unsigned short *w = (unsigned short *)hw->words;
  int whatword, whatbit;
  unsigned short mask = 1;

  whatword = n / LONG_BIT;
  whatbit = n % LONG_BIT;
  /*if((whatword < 0) || (whatword >= 6)) return(False);*/
  mask <<= whatbit;

  return((w[whatword] & mask) == mask);
}

void
SetBitWord112(Word112Ptr hw, int n)
{
  unsigned short *w = (unsigned short *)hw->words;
  int whatword, whatbit;
  unsigned short mask = 1;

  whatword = n / LONG_BIT;
  whatbit = n % LONG_BIT;
  /*if((whatword < 0) || (whatword >= 6)) return;*/
  mask <<= whatbit;
  w[whatword] |= mask;

  return;
}

void
ClearWord112(Word112Ptr hw)
{
  memset(hw->words,0,sizeof(Word112));

  return;
}

void
NegateWord112(Word112Ptr hw)
{
  int i;
  unsigned short *w = (unsigned short *)hw->words;
  for(i=0; i<NW256; i++) w[i] = ~w[i];
  return;
}




/******************************************************/
/* two 'Bleed' functions specific for noise reduction */

void
BleedRightWord112(Word112Ptr hw, int n)
{
  int j, m, k;
  Word112 thw;

  CopyWord112(hw, &thw);
  if(n < 4)
  {
    for(j=0; j<n; j++)
    {
      RightShiftWord112(&thw, 1);
      ORWord112(hw, &thw, hw);
    }
    return;
  }

  m = (n+1)/2;
  k = n-m;

  for(j=0; j<m; j++)
  {
    RightShiftWord112(&thw, 1);
    ORWord112(hw, &thw, hw);
  }
  
  CopyWord112(hw, &thw);
  RightShiftWord112(&thw, k);
  ORWord112(hw, &thw, hw);

  return;
}

void
BleedLeftWord112(Word112Ptr hw, int n)
{
  int j, m, k;
  Word112 thw;

  CopyWord112(hw, &thw);
  if(n < 4)
  {
    for(j=0; j<n; j++)
    {
      LeftShiftWord112(&thw, 1);
      ORWord112(hw, &thw, hw);
    }
    return;
  }

  m = (n+1)/2;
  k = n-m;

  for(j=0; j<m; j++)
  {
    LeftShiftWord112(&thw, 1);
    ORWord112(hw, &thw, hw);
  }

  CopyWord112(hw, &thw);
  LeftShiftWord112(&thw, k);
  ORWord112(hw, &thw, hw);

  return;
}












/****************************************************************************/
/****************************************************************************/
/****************************************************************************/


/*******************/
/* 3 layers 4 bits */
/*******************/

/*correct*/
#define ADR30 ((b0   )&0xF)  + ((b1&0xF)<<4)         + ((b2&0xF)<<8)
#define ADR31 ((b0>>4)&0xF)  + ((b1&0xF0)   )        + ((b2&0xF0)<<4)
#define ADR32 ((b0>>8)&0xF)  + ((b1&0xF00)>>4)       + ((b2&0xF00)   )
#define ADR33 ((b0>>12)&0xF) + ((b1&0xF000)>>8)      + ((b2&0xF000)>>4)


#define SLMIN2 (b1|b2)
unsigned short
slmin2(unsigned short b0, unsigned short b1, unsigned short b2)
{
  return(b1|b2);
}
#define SLMIN3 ((b0&b1)|b2)
unsigned short
slmin3(unsigned short b0, unsigned short b1, unsigned short b2)
{
  return((b0&b1)|b2);
}
#define SLMIN4 (b2)
unsigned short
slmin4(unsigned short b0, unsigned short b1, unsigned short b2)
{
  return(b2);
}
#define SLMIN5 ((b0&b2)|(b1&b2))
unsigned short
slmin5(unsigned short b0, unsigned short b1, unsigned short b2)
{
  return((b0&b2)|(b1&b2));
}
#define SLMIN6 (b1&b2)
unsigned short
slmin6(unsigned short b0, unsigned short b1, unsigned short b2)
{
  return(b1&b2);
}
#define RGMIN8 (b3)
unsigned short
rgmin8(unsigned short b0, unsigned short b1, unsigned short b2, unsigned short b3)
{
  return(b3);
}

#define SLMIN SLMIN3
#define RGMIN 5 /* was 6 */


#define NPEAK  100
#define NCAND  (MAXSEGM*NGAP*2)
















/******************************************************************************
 TWOSLPROCESS: bit map processing for 2 SL and match them

   1. copy axial[0..NLAY] -> axwork[0..NLAY]
   2. copy stereo[0..NLAY] -> stwork[0..NLAY]
   3. shift stwork[0..NLAY] to the left on NGAP bits
   4. loop over nsegment6 shifts in according to dshift[] table:
      - shifts every layer in both axial and stereo
      - calls SUPERLAYER macros for both axial and stereo
      - fills following arrays/variables:
          *pax (pointer to tmp1[][])
          *pst (pointer to tmp2[][])
          *mkax (pointer to mask1[])
          *mkst (pointer to mask2[])
          stat

******************************************************************************/

#define PRINTSL(notation, array_name)			\
  printf("\n"); printf(notation);	printf("\n");				\
  PrintWord112(&array_name[5]);	\
  PrintWord112(&array_name[4]);	\
  PrintWord112(&array_name[3]);	\
  PrintWord112(&array_name[2]);	\
  PrintWord112(&array_name[1]);	\
  PrintWord112(&array_name[0])


/* 160micros */
void
SegmentSearch112(Word112 axial[6], int *ncl, PRRG *clust)
{
  int nsg, sgwire[NPEAK], sgmax[NPEAK], sgshift[NPEAK], sgphi[NPEAK];
  /* temporary input data storage and corresponding pointers */
  Word112 axwork[6];
  unsigned short *ax0 = (unsigned short *)axwork[0].words;
  unsigned short *ax1 = (unsigned short *)axwork[1].words;
  unsigned short *ax2 = (unsigned short *)axwork[2].words;
  unsigned short *ax3 = (unsigned short *)axwork[3].words;
  unsigned short *ax4 = (unsigned short *)axwork[4].words;
  unsigned short *ax5 = (unsigned short *)axwork[5].words;
/* NCAND too big, local cannot be so big ???!!! use 'static' ... */
  static int listr[NCAND][112], phir[NCAND][112], nhitr[NCAND][112];
  /* other local variables */
  int i, j, k, m, n, itmp, imax, iwtmp, imaxs, nclust, stat3;
  unsigned short b0, b1, b2, tmp;
  unsigned char tmp1[MAXSEGM][112];
  unsigned int *pax = (unsigned int *)&tmp1[0][0];
  Word112 mask1[MAXSEGM];
  unsigned short *mkax;
  int stat;


  stat = 0;
  for(i=0; i<NOFFSETS; i++) for(j=0; j<NW112; j++)
  {
    out[i][j]=0;
  }

#ifdef DEBUG
  PRINTSL("axial",axial);
#endif


#ifdef TRIGGER_STYLE

  for(i=0; i<6; i++)
  {
    for(j=0; j<NWIRESTOT; j++) input[i][j]=0;
  }
  for(i=0; i<NOFFSETS; i++)
  {
    for(j=0; j<NWIRES; j++) outputt[i][j]=0;
  }
  for(i=0; i<6; i++)
  {
    for(j=0; j<NWIRES; j++)
	{
      if(CheckBitWord112(&axial[i], j)) input[i][j+NBLEED] = 1;
	}
  }

  for(j=0; j<NWIRES; j++) dcsegfinder(4, j, input, outputt);

  /* print output */
  /*
  printf("TRIGSIM INPUT\n");
  for(i=5; i>=0; i--)
  {
    printf("> ");
    for(j=NWIRES-1; j>.0; j--)
	{
      if(input[i][j+NBLEED]) printf("X");
      else                   printf("-");
	}
    printf("\n");
  }
  printf("\n");
  */
  /*printf("TRIGSIM OUTPUT\n");*/
  for(i=0; i<NOFFSETS; i++)
  {
    printf("%3d> ",(15-i)-8);
    for(j=NWIRES-1; j>=0; j--)
	{
      if(!((j+1)%16) && j<111) printf(" ");
      if(outputt[i][j]) printf("X");
      else              printf("-");
	}
    printf("\n");
  }
  /*printf("\n");*/




#else /*TRIGGER_STYLE*/





  for(i=0;i<nsegment6;i++) for(j=0;j<112;j++) {tmp1[i][j]=0;}


  /*about 63micros*/
  for(i=0; i<NLAY; i++)
  {
    CopyWord112(&axial[i], &axwork[i]);
  }

#ifdef DEBUG
  PRINTSL("axwork",axwork);
#endif

  /*shift using first segment*/
  for(i=1; i<NLAY; i++)
  {
    itmp = -shift[0][i-1];
    RightShiftWord112(&axwork[i], itmp);
  }

#ifdef DEBUG
  PRINTSL("axwork after shift",axwork);
#endif

  for(j=0; j<nsegment6; j++)
  {
    for(i=1; i<6; i++) /* loop over layers */
    {
      itmp = dshift[j][i-1];
      if(itmp==0)
      {
        ;
	  }
      else if(itmp>0)
      {
        LeftShiftWord112(&axwork[i],/*1*/itmp);
      }
      else
      {
        RightShiftWord112(&axwork[i],/*1*/-itmp);
      }
    }
    mkax = (unsigned short *)mask1[j].words;


    /* search for bits with minimum 'SLMIN' hits */

    for(i=0; i<NW112; i++)
    {
      b1 = (*ax0)&(*ax1);
      b0 = (*ax0)^(*ax1);
      b1 = (b1)^((b0)&(*ax2));
      b0 = (b0)^(*ax2);
      tmp = (b0)&(*ax3);
      b2 = (b1)&tmp;
      b1 = (b1)^tmp;
      b0 = (b0)^(*ax3);
      tmp = (b0)&(*ax4);
      b2 = (b2)^((b1)&tmp);
      b1 = (b1)^tmp;
      b0 = (b0)^(*ax4);
      tmp = (b0)&(*ax5);
      b2 = (b2)^((b1)&tmp);
      b1 = (b1)^tmp;
      b0 = (b0)^(*ax5);
      stat |= *mkax++ = SLMIN4;

      /* output array */
      out[shift[j][4]+8][i] |= *(mkax-1);

      /* convert vertical binary code to unsigned chars ('pax' points to 'tmp1[0][0]') */
      *pax++ = look[ADR30];
      *pax++ = look[ADR31];
      *pax++ = look[ADR32];
      *pax++ = look[ADR33];

	  
	  if( (*(mkax-1)) > 0)
	  {
        printf("shift=%d (layer 6 offset=%d) word=%d mkax=0x%04x\n",j,shift[j][4],i,*(mkax-1));
        BinaryPrint16(b2);printf("\n");
        BinaryPrint16(b1);printf("\n");
        BinaryPrint16(b0);printf("\n");
        printf("ADRS: 0x%03x 0x%03x 0x%03x 0x%03x\n",ADR33,ADR32,ADR31,ADR30);
		{
          int ii;
          unsigned char *pp = (unsigned char *) (pax-4);
          for(ii=15; ii>=0; ii--) printf("%3d",pp[ii]);
          printf("\n");
        }
	  }
	  

      ax0++; ax1++; ax2++; ax3++; ax4++; ax5++;
    }
    ax0 -= NW112;
    ax1 -= NW112;
    ax2 -= NW112;
    ax3 -= NW112;
    ax4 -= NW112;
    ax5 -= NW112;

  }


#endif /*TRIGGER_STYLE*/






#ifdef DEBUG
    printf("\n\nOUTPUT ARRAY:\n\n");
    for(i=(NOFFSETS-1); i>=0; i--)
	{
      printf("%3d> ",i-8);
      for(j=(NW112-1); j>=0; j--)
      {
        BinaryPrint16(out[i][j]);
        printf(" ");
        /*printf(" 0x%04x",out[i][j]);*/
      }
      printf("\n");
	}

    /*printf("\n\n");*/

	/*	
    printf("shift ->   ");
    for(j=0; j<nsegment6; j++)
    {
      printf("%3d",j);
    }
    printf("\n");
    for(i=0; i<112; i++)
	{
      printf("wire #%3d: ",i);
      for(j=0; j<nsegment6; j++)
      {
        printf("%3d",tmp1[j][i]);
      }
      printf("\n");
	}
	*/
#endif

  return;
}


void
SuperLayerSum(Word112 data[6], Word112Ptr output)
{
  int i;
  unsigned short b0, b1, b2, tmp;
  unsigned short *out = (unsigned short *)output->words;
  unsigned short *w0 = (unsigned short *)data[0].words;
  unsigned short *w1 = (unsigned short *)data[1].words;
  unsigned short *w2 = (unsigned short *)data[2].words;
  unsigned short *w3 = (unsigned short *)data[3].words;
  unsigned short *w4 = (unsigned short *)data[4].words;
  unsigned short *w5 = (unsigned short *)data[5].words;

  for(i=0; i<NW112; i++)
  {
    b1 = (*w0)&(*w1);
    b0 = (*w0++)^(*w1++);
    b1 = (b1)^((b0)&(*w2));
    b0 = (b0)^(*w2++);

    tmp = (b0)&(*w3);
    b2 = (b1)&tmp;
    b1 = (b1)^tmp;
    b0 = (b0)^(*w3++);

    tmp = (b0)&(*w4);
    b2 = (b2)^((b1)&tmp);
    b1 = (b1)^tmp;
    b0 = (b0)^(*w4++);

    tmp = (b0)&(*w5);
    b2 = (b2)^((b1)&tmp);
    b1 = (b1)^tmp;
    b0 = (b0)^(*w5++);
      
    *out++ = SLMIN3;
  }

  return;
}


/********************* RemoveNoise ***************************
  Input:
    Word112  data[6] - actual data with noise 
    int     *layershifts - 
  Output:
    Word112  data[6] - cleaned data
**************************************************************/

int
RemoveNoise(Word112 data[6], int *layershifts)
{
  int i, itmp;
  Word112 workspace[6], wrk;
  Word112 Lsegments, Rsegments; /* cumulative left & right segments */
  int nlayers = 6;


  /**************************/
  /* look for segment areas */

  /* copy data[] to workspace[] and shift the data for each layer
     according to the layer shift (i.e the buckets) in both
     left and right directions */


  /*memcpy(workspace, data, nlayers*sizeof(Word112));*/
  for(i=0; i<nlayers; i++)
  {
    CopyWord112(&data[i], &workspace[i]);
  }


  for(i=1; i<nlayers; i++) BleedRightWord112(&workspace[i], layershifts[i]);
  SuperLayerSum(workspace, &Lsegments);


  /*memcpy(workspace, data, nlayers*sizeof(Word112));*/
  for(i=0; i<nlayers; i++)
  {
    CopyWord112(&data[i], &workspace[i]);
  }


  for(i=1; i<nlayers; i++) BleedLeftWord112(&workspace[i], layershifts[i]);
  SuperLayerSum(workspace, &Rsegments);


  /************************/
  /* now remove the noise */

  /* first, set workspace[0] to contain overlap of both sets of segments
  NOTE: the first layer (layer 0) NEVER has a layer shift */

  ORWord112(&Lsegments, &Rsegments, &workspace[0]);
/*
printf("LRsegm\n");
PrintWord112(&workspace[0]);
*/
  ANDWord112(&data[0], &workspace[0], &data[0]);

  for(i=1; i<nlayers; i++)
  {
    /* copy segments onto a given layer and bleed to create left
    and right buckets */

    CopyWord112(&Lsegments, &workspace[i]);
    BleedLeftWord112(&workspace[i], layershifts[i]);

    CopyWord112(&Rsegments, &wrk);
    BleedRightWord112(&wrk, layershifts[i]);

    /* combine left and right buckets */
    ORWord112(&workspace[i], &wrk, &workspace[i]);

    /* now get overlap of original data with buckets */
    ANDWord112(&data[i], &workspace[i], &data[i]);
  }

  /*
  printf("workspace\n");
  for(i=0; i<NW112; i++) PrintWord112(&workspace[i]);
  */

  /* check if we found at least something in the superlayer */
  for(i=0; i<NW112; i++) if(workspace[0].words[i] & 0xFFFFFFFF) return(1);

  return(0);
}







/**************************************************************************/
/**************************************************************************/
/**************************************************************************/






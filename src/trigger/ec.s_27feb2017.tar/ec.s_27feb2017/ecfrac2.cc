/* ecfrac2.c - energy fractions calculation

  input:  

  output: 
*/


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

using namespace std;
#include <strstream>


#define MAX(a,b)    (a > b ? a : b)
#define MIN(a,b)    (a < b ? a : b)
#define ABS(x)      ((x) < 0 ? -(x) : (x))


#ifdef USE_PCAL

#include "../pc.s/pclib.h"
#define ecfrac pcfrac
#define ecfrac1 pcfrac1
#define ecfrac2 pcfrac2
#define ecfrac3 pcfrac3
#define ecfracratio pcfracratio

#else

#include "eclib.h"

#endif


#define DEBUG

#include <ap_fixed.h>



#define FACTOR1 256/*128*/
#define SHIFT1  8


/*xc7vx550tffg1158-1*/


/* 2.99/6/2/0%/0%/1%/1% */




void
ecfrac2(hitsume_t hitouttmp1[NPEAK][NPEAK][NPEAK], hitsume_t hitouttmp2[NPEAK][NPEAK][NPEAK])
{
#pragma HLS ARRAY_PARTITION variable=hitouttmp1 complete dim=1
#pragma HLS ARRAY_PARTITION variable=hitouttmp1 complete dim=2
#pragma HLS ARRAY_PARTITION variable=hitouttmp1 complete dim=3
#pragma HLS ARRAY_PARTITION variable=hitouttmp2 complete dim=1
#pragma HLS ARRAY_PARTITION variable=hitouttmp2 complete dim=2
#pragma HLS ARRAY_PARTITION variable=hitouttmp2 complete dim=3
#pragma HLS PIPELINE

  uint8_t i,j,u,v,w;
  /*fp1803_t*/ap_uint<32> peak_sumE[3][NPEAK];

#ifdef DEBUG
  cout<<endl;
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac2!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac2!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
#endif


  for(i=0; i<3; i++)
  for(j=0; j<NPEAK; j++)
  {
    peak_sumE[i][j] = 0;
  }

  for(u=0; u<NPEAK; u++)
  for(v=0; v<NPEAK; v++)
  for(w=0; w<NPEAK; w++)
  {
    peak_sumE[0][u] += hitouttmp1[u][v][w].peak_sumE[0];
    peak_sumE[1][v] += hitouttmp1[u][v][w].peak_sumE[1];
    peak_sumE[2][w] += hitouttmp1[u][v][w].peak_sumE[2];
  }


#ifdef DEBUG
  for(i=0; i<3; i++)
  for(j=0; j<NPEAK; j++)
  {
    if(peak_sumE[i][j]>0) cout<<"peak_sumE["<<+i<<"]["<<+j<<"]="<<peak_sumE[i][j]<<endl;
  }
#endif


  /* move it from [3][u/v/w] to [u][v][w] */
  for(u=0; u<NPEAK; u++)
  for(v=0; v<NPEAK; v++)
  for(w=0; w<NPEAK; w++)
  {
    hitouttmp2[u][v][w].sumE         = hitouttmp1[u][v][w].sumE; /* for check below .. */
    hitouttmp2[u][v][w].peak_sumE[0] = peak_sumE[0][u];
    hitouttmp2[u][v][w].peak_sumE[1] = peak_sumE[1][v];
    hitouttmp2[u][v][w].peak_sumE[2] = peak_sumE[2][w];
  }





#ifdef DEBUG
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac2!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac2!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
#endif

  return;
}

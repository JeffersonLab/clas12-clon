/* ecfrac3.c - energy fractions calculation

  input:  

  output: 
*/


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

using namespace std;
#include <strstream>


#define MAX(a,b)    (a > b ? a : b)
#define MIN(a,b)    (a < b ? a : b)
#define ABS(x)      ((x) < 0 ? -(x) : (x))


#ifdef USE_PCAL

#include "../pc.s/pclib.h"
#define ecfrac pcfrac
#define ecfrac1 pcfrac1
#define ecfrac2 pcfrac2
#define ecfrac3 pcfrac3
#define ecfracratio pcfracratio

#else

#include "eclib.h"

#endif


#define DEBUG

#include <ap_fixed.h>


#define FACTOR1 256/*128*/
#define SHIFT1  8









/****************************/
/****************************/
/* playing with deviding .. */

#define MAX(a,b)    (a > b ? a : b)

/*
      temp1 = energy;
      temp2 = peakfrac[axis][peakid];
      n1 = get_addr_shift(temp1);
      n2 = get_addr_shift(temp2);
      n = MAX(n1,n2);
      temp3 = coeff1_get(temp1,temp2,n,coeff1);
*/

#define WIN1_LEN  16384 /* max size available for now !!! */

static void
coeff1_init(ap_uint<8> rom_array[WIN1_LEN])
{
  int i,j,k;

  /* fraction(8bit) = energy(7bit) / energy(7bit) */
  for(k=0; k<WIN1_LEN; k++)
  {
    j = k&0x7F;
    i = (k>>7)&0x7F;
    if(j==0) rom_array[k] = 0;
    else rom_array[k] = (ap_uint<8>)( ((float)(i))*((float)(FACTOR1))/((float)(j)) );
    /*printf("coeff1_init: i=%3d j=%4d k=%7d -> data=%5d\n",i,j,k,rom_array[k]);*/
  }
}

static uint8_t
get_addr_shift(uint16_t addr)
{
#pragma HLS INLINE
#pragma HLS PIPELINE
  uint8_t nn;

  if(addr&0x8000)      nn = 9;
  else if(addr&0x4000) nn = 8;
  else if(addr&0x2000) nn = 7;
  else if(addr&0x1000) nn = 6;
  else if(addr&0x0800) nn = 5;
  else if(addr&0x0400) nn = 4;
  else if(addr&0x0200) nn = 3;
  else if(addr&0x0100) nn = 2;
  else if(addr&0x0080) nn = 1;
  else                 nn = 0;

  return(nn);
}

static uint8_t
get_shift24(ap_uint<24> addr)
{
#pragma HLS INLINE
#pragma HLS PIPELINE
  uint8_t nn;

  if     (addr&0x800000) nn = 17;
  else if(addr&0x400000) nn = 16;
  else if(addr&0x200000) nn = 15;
  else if(addr&0x100000) nn = 14;
  else if(addr&0x080000) nn = 13;
  else if(addr&0x040000) nn = 12;
  else if(addr&0x020000) nn = 11;
  else if(addr&0x010000) nn = 10;
  else if(addr&0x008000) nn = 9;
  else if(addr&0x004000) nn = 8;
  else if(addr&0x002000) nn = 7;
  else if(addr&0x001000) nn = 6;
  else if(addr&0x000800) nn = 5;
  else if(addr&0x000400) nn = 4;
  else if(addr&0x000200) nn = 3;
  else if(addr&0x000100) nn = 2;
  else if(addr&0x000080) nn = 1;
  else                   nn = 0;

  return(nn);
}

static ap_uint<8>
coeff1_get(uint32_t addr1, uint32_t addr2, uint8_t n, ap_uint<8> rom_array[WIN1_LEN])
{
#pragma HLS INLINE
#pragma HLS PIPELINE
  ap_uint<8> ret;
  uint8_t  temp1,temp2;
  uint16_t addr;

  temp1 = (addr1>>n)&0x7F;
  temp2 = (addr2>>n)&0x7F;

  /*printf("+++ n1=%d n2=%d\n",n1,n2);*/

  addr = (temp1<<7)|temp2;
  ret = rom_array[addr];

  return(ret);
}


/****************************/
/****************************/
/****************************/















/*xc7vx550tffg1158-1*/


/* 3.03/26/2/0%/0%/33%/53%  (fixed 18.3) */
/* 2.89/23/2/0%/0%/19%/29%  (uint8_t) */
/* 2.89/23/2/0%/0%/16%/23%  (uint16_t) */

/* 2.78/7/2/16%/0%/2%/12% (RAM) */

/*
Generating core module 'ecfrac3_udiv_24ns_21ns_24_28': 192 instance(s). 1269 FFs and 1269 LUTs each
Generating pipelined core: 'ecfrac3_udiv_24ns_21ns_24_28_div
	*/

void
ecfrac3(hitsume_t hitouttmp2[NPEAK][NPEAK][NPEAK], uint16_t fracout[NPEAK][NPEAK][NPEAK][3])
{
#pragma HLS ARRAY_PARTITION variable=hitouttmp2 complete dim=1
#pragma HLS ARRAY_PARTITION variable=hitouttmp2 complete dim=2
#pragma HLS ARRAY_PARTITION variable=hitouttmp2 complete dim=3
#pragma HLS ARRAY_PARTITION variable=fracout complete dim=1
#pragma HLS ARRAY_PARTITION variable=fracout complete dim=2
#pragma HLS ARRAY_PARTITION variable=fracout complete dim=3
#pragma HLS ARRAY_PARTITION variable=fracout complete dim=4
#pragma HLS PIPELINE

  static ap_uint<8> coeff1[WIN1_LEN];

  uint8_t i,u,v,w;
  hitsume_t hitouttmp;
  uint32_t fractmp;

  uint32_t temp1, temp2;
  uint8_t tmp1, tmp2;
  uint8_t n1, n2, n;

  coeff1_init(coeff1);

#ifdef DEBUG
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac3!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac3!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
#endif


  for(u=0; u<NPEAK; u++)
  for(v=0; v<NPEAK; v++)
  for(w=0; w<NPEAK; w++)
  {
	if(hitouttmp2[u][v][w].sumE>0)
	{
      hitouttmp = hitouttmp2[u][v][w];
      fractmp = (hitouttmp.sumE) * FACTOR1;
      for(i=0; i<3; i++)
      {
        if(hitouttmp.peak_sumE[i]==0)
 	    {
          fracout[u][v][w][i] = FACTOR1;
#ifdef DEBUG
		  cout<<" ["<<+u<<"]["<<+v<<"]["<<+w<<"]["<<+i<<"] no_divide: fracout="<<fracout[u][v][w][i]<<endl;
#endif
 	    }
        else
 	    {


          temp1 = hitouttmp.sumE;
          temp2 = hitouttmp.peak_sumE[i];


		  /* assumes that temp2 always bigger then temp1
          n1 = get_shift24(temp1);
          n2 = get_shift24(temp2);
          n = MAX(n1,n2);
		  */
          n = get_shift24(temp2);


		  /*
          tmp1 = (temp1>>n)&0xFF;
          tmp2 = (temp2>>n)&0xFF;
          if(tmp2>0) fracout[u][v][w][i] = tmp1 / tmp2;
          else fracout[u][v][w][i] = 0;
		  */
		  fracout[u][v][w][i] = coeff1_get(temp1,temp2,n,coeff1) + 1; /* lookup table returns from 0 to 255, make it from 1 to 256 */




		  /*fracout[u][v][w][i] = fractmp / hitouttmp.peak_sumE[i];*/




#ifdef DEBUG
		  cout<<" ["<<+u<<"]["<<+v<<"]["<<+w<<"]["<<+i<<"] dividing1: "<<hitouttmp.sumE<<" / "<<hitouttmp.peak_sumE[i]<<" = "<<fracout[u][v][w][i]<<endl;
		  cout<<" ["<<+u<<"]["<<+v<<"]["<<+w<<"]["<<+i<<"] dividing2: "<<fractmp<<" / "<<hitouttmp.peak_sumE[i]<<" = "<<(fractmp/hitouttmp.peak_sumE[i])<<endl;
#endif
 	    }
      }
	}
    else
	{
      for(i=0; i<3; i++)
	  {
        fracout[u][v][w][i] = FACTOR1;
#ifdef DEBUG
		cout<<" ["<<+u<<"]["<<+v<<"]["<<+w<<"]["<<+i<<"] donothing: fracout="<<fracout[u][v][w][i]<<endl;
#endif
	  }
	}
  }

#ifdef DEBUG
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac3!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
  cout <<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ecfrac3!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<< endl;
#endif

  return;
}

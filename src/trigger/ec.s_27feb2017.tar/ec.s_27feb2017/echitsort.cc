/* echitsort - "sorting" hits

  input:  hitin - input hits array

  output: hitout - output hits array
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

using namespace std;
#include <strstream>


#define MAX(a,b)    (a > b ? a : b)
#define MIN(a,b)    (a < b ? a : b)
#define ABS(x)      ((x) < 0 ? -(x) : (x))


//#define DEBUG

#ifdef USE_PCAL

#include "../pc.s/pclib.h"
#define echitsort pchitsort

#else

#include "eclib.h"

#endif



//#define NHIT 64

uint8_t
echitsort(ECHit hitin[64], ECHit hitout[NHIT])
{
#pragma HLS ARRAY_PARTITION variable=hitin complete dim=1
//#pragma HLS ARRAY_PARTITION variable=hitout complete dim=1
#pragma HLS PIPELINE
  uint8_t i, ihit;
  uint8_t ind;
  uint16_t energy;

#ifdef DEBUG
  printf("\n+++ echitsort start +++\n\n");
#endif

  ihit = 0;
  for(ind=0; ind<64; ind++)
  {
    energy = hitin[ind].energy;
    if(energy>0)
	{
      for(i=0; i<3; i++) hitout[ihit].coord[i] = hitin[ind].coord[i];
      hitout[ihit].energy = energy;

#ifdef DEBUG
      cout<<"   result: coordU="<<hitout[ihit].coord[0]<<", coordV="<<hitout[ihit].coord[1]<<", coordW="<<hitout[ihit].coord[2]<<" -> energy="<<hitout[ihit].energy<<endl;fflush(stdout);
#endif
      ihit ++;
      if(ihit >= NHIT) break;
	}
  }

#ifdef DEBUG
  printf("\n+++ echitsort done +++\n\n");
#endif

  return(ihit);
}




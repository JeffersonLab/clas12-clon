#define USE_PCAL
#include "../ec.s/ecpeaksort.cc"

/* 2.66/84/1/0%/0%/17%/46% - sorting network */

/* 3.36/241/1/0%/0%/3%/25% - pipeline, all complete */
/* 3.36/241/4/0%/0%/3%/17% - pipeline II=4, all complete */

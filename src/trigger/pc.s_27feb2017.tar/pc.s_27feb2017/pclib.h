#ifndef _PCLIB_

#include <ap_int.h>
#include <hls_stream.h>

#define USE_PCAL

#ifdef	__cplusplus
extern "C" {
#endif

/* pclib.h */


/************************/
/* some control defines */

/*#define NO_ATTEN*/ /* defining that will suppress attenuation correction */

#define DO_DIVIDE /* will do actial division instead of lookup table */

/* some control defines */
/************************/



#define PSTRIP    68
#define PSTRIPMAX 84
#define PPEAKMAX  10/*(PSTRIPMAX/2)*/
#define PLAYER    3
#define PSECTOR   6
#define PPEAK     4
#define PHIT      10


#define NSTRIP0   PSTRIP
#define NSTRIP    PSTRIPMAX
#define NPEAKMAX  PPEAKMAX
#define NLAYER    PLAYER
#define NSECTOR   PSECTOR
#define NPEAK     PPEAK
#define NHIT      PHIT
#define NHITMAX   (NPEAK*NPEAK*NPEAK) /* array size if index is calculated as 'u+(v<<2)+(w<<4)' */


typedef struct ecstrip *ECStripPtr;
typedef struct ecstrip
{
  ap_uint<13> energy;       /* strip energy */
} ECStrip;




#define ECPEAK0_ENERGY_MASK 0xFFFF
#define ECPEAK0_STRIP1_MASK 0x7F
#define ECPEAK0_STRIPN_MASK 0x7F
#define ECPEAK0_ENESUM_MASK 0xFFFFFF

#define ECPEAK0_ENERGY_BITS 16
#define ECPEAK0_STRIP1_BITS 7
#define ECPEAK0_STRIPN_BITS 7
#define ECPEAK0_ENESUM_BITS 24

#define ECPEAK0_BITS (ECPEAK0_ENERGY_BITS+ECPEAK0_STRIP1_BITS+ECPEAK0_STRIPN_BITS+ECPEAK0_ENESUM_BITS)




typedef struct trigecpeak *TrigECPeakPtr;
typedef struct trigecpeak
{
  ap_uint<16> coord;
  ap_uint<16> energy;
  ap_uint<16> time;

} TrigECPeak;


typedef struct trigechit *TrigECHitPtr;
typedef struct trigechit
{
  ap_uint<16> coord[3];
  ap_uint<16> energy;
  ap_uint<16> time;

} TrigECHit;




typedef struct ecpeak0 *ECPeak0Ptr;
typedef struct ecpeak0
{
  ap_uint<16> energy;          /* peak energy */
  ap_uint<7>  strip1;          /* first strip in peak */
  ap_uint<7>  stripn;          /* the number of strips in peak */
  ap_uint<24> energysum4coord; /* pass it to next function to do coordinate calculation */

} ECPeak0;

typedef struct ecpeak *ECPeakPtr;
typedef struct ecpeak
{
  ap_uint<16> energy;       /* peak energy */
  ap_uint<16> coord;        /* peak coordinate in (strip#<<3) units */
  ap_uint<7>  strip1;       /* first strip in peak */
  ap_uint<7>  stripn;       /* the number of strips in peak */

} ECPeak;

typedef struct ecpeak1 *ECPeak1Ptr;
typedef struct ecpeak1
{
  ap_uint<16> energy;       /* peak energy */
  ap_uint<7>  nhits;        /* the number of hits where this peak participates */
  ap_uint<7>  hitid[NHIT];

} ECPeak1;


typedef struct echit *ECHitPtr;
typedef struct echit
{
  ap_uint<16> energy;       /* hit energy */
  ap_uint<16> coord[3];     /* u/v/w coordinate */

} ECHit;






#define NUMBER_OF_BITS_DECIMAL	 18
#define NUMBER_OF_BITS_FRACTIONAL 3
typedef ap_ufixed<(NUMBER_OF_BITS_DECIMAL+NUMBER_OF_BITS_FRACTIONAL),NUMBER_OF_BITS_DECIMAL> fp1803_t;
//typedef ap_uint<24> fp1803_t;




//typedef ap_ufixed<2, 1, AP_RND, AP_SAT> fp0201S_t;
typedef ap_uint<6> fp0201S_t;




typedef struct ecpeakout *ECPeakoutPtr;
typedef struct ecpeakout
{
  ap_uint<16> energy;       /* peak energy */
  ap_uint<4>  hitid;        /* hit id this peak participating in */
  fp1803_t    sumE0;         

} ECPeakout;

typedef ECPeakout peakout_t;

typedef struct echitout *ECHitoutPtr;
typedef struct echitout
{
  ap_uint<16> energy[3];    /* peak energies */
  ap_uint<16> coord[3];     /* u/v/w coordinate */

} ECHitout;

/*typedef ap_uint<96> hitout_t;*/
typedef ECHitout hitout_t;

typedef struct echitsume *ECHitSumEPtr;
typedef struct echitsume
{
  fp1803_t    sumE;         /* sum of energies for UNIQUE peaks only normalized for the number of peaks (E = E / Nvalid) */
  fp1803_t    peak_sumE[3];

} ECHitSumE;
typedef ECHitSumE hitsume_t;



/* functions */


int  pcinit(int runnum, int def_adc, int def_tdc, int def_atten);
int  pcstrips(unsigned int *bufptr, unsigned short threshold, int sec, ECStrip strip[NLAYER][NSTRIP]);
int  pcl3(unsigned int *bufptr, const unsigned short threshold[3], int io, ECHit hit[NHIT]);

int  pcstrip(uint8_t view, ECStrip stripin[NSTRIP0], ECStrip stripout[NSTRIP]);
int  pcpeak(unsigned short strip_threshold, ECStrip strip[36], ECPeak0 peak[NSTRIP]);
int  pcpeaksort(ECPeak0 peakin[NSTRIP], ECPeak0 peakout[NPEAK]);
int  pcpeakcoord(uint8_t view, ECPeak0 peakin[NPEAK], ECPeak peakout[NPEAK]);
int  pchit(ECPeak peak[3][NPEAK], fp0201S_t peakcount[3][NPEAK], hitout_t hitout[NPEAK][NPEAK][NPEAK]);

void pcfrac(fp0201S_t peakcount[3][NPEAK], hitout_t hitout[NPEAK][NPEAK][NPEAK], uint16_t fffout[NPEAK][NPEAK][NPEAK][3]);
uint8_t pccorr(uint16_t threshold, hitout_t hitin[NPEAK][NPEAK][NPEAK], uint16_t fffout[NPEAK][NPEAK][NPEAK][3],   ECHit hithit[NPEAK][NPEAK][NPEAK]);

uint8_t echitsort(ECHit hithit[NPEAK][NPEAK][NPEAK], ECHit hit[NHIT]);
uint8_t pcal(ECStrip strip[3][36], uint8_t *nhits, ECHit hit[NHIT]);

uint16_t pcal_coord_to_strip(uint8_t view, uint16_t jj);




  /* for PCAL 'normalization' */
#define UVWADD  40/*average between 77/2 and 84/2*/
#define UFACTOR 77
#define VFACTOR 84
#define WFACTOR 84
static uint8_t fview[3] = {UFACTOR,VFACTOR,WFACTOR};




#ifdef DEBUG
#define MAXDALZ 100
#endif





#ifdef	__cplusplus
}
#endif


#define _PCLIB_
#endif

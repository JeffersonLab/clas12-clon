#define USE_PCAL
#include "../ec.s/ecpeak.cc"

/* 3.40/143/42/0%/2%/2%/6%*/

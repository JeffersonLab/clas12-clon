#define USE_PCAL
#include "../ec.s/ecfrac.cc"

/* 3.36/64/12/0%/0%/2%/6% */
